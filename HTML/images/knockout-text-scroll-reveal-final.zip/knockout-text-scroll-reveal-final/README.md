# Knockout Text Scroll Reveal (Final)

A Pen created on CodePen.io. Original URL: [https://codepen.io/blakeeric/pen/MWwGpmR](https://codepen.io/blakeeric/pen/MWwGpmR).

